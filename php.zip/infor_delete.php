<?php
   $infor_id = $_REQUEST["infor_id"];
	   
	require("db_connect.php"); //db접속
    $query = $db -> exec("delete from information where infor_id=$infor_id"); 
   
       header("Location:information.php");
?>

 

