<?php
   $infor_id = $_REQUEST["infor_id"];
   
   $title = $_REQUEST["title"];
   $content = $_REQUEST["content"];
   $writer = $_REQUEST["writer"];
   
   if ($title && $content && $writer){
	   $regtime = date("Y-m-d");
	   
	   require("db_connect.php"); //db접속
       $query = $db -> exec("update information set 
	                             title='$title', content='$content', writer='$writer',
								 regtime='$regtime' where infor_id=$infor_id"); 
   
       header("Location:iview.php?infor_id=$infor_id");
	   exit; //헤더 쓰면 exit 써주면 좋다
   }

 
   
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<script>
   alert('모든 항목이 빈칸 없이 입력되어야 합니다.');
   history.back();
</script>
</body>
</html>
