<!doctype html>
<html>
<head>
    <meta charset="utf-8">
	<style>
	td { font-size: 20px;}
	</style>
</head>
<body>
<input type="button" value="뒤로 가기" onclick="history.back()"><br>
<table border="1" align = "center">
<th>설명</th>
	<th>이미지 참조</th>
<tr>
<td>1. 시험문제 올리는 방법<br>시험문제 이미지 주소를 복사 후 src에 붙여넣기 하면 됩니다.</td>
<td><img src = "extest.jpg"></td>
</tr>
<tr>
<td>2. 입시정보 올리는 방법<br>네이버에서 입시 정보 이미지 주소를 복사 후 src에 붙여넣기 하면 됩니다.</td><br>
<td><img src = "infor/exinfor.jpg"></td>       
</tr>
<tr>
<td>3. 인강 올리는 방법<br>유튜브나 네이버 동영상을 통해 마우스 우클릭 후 소스코드 복사!!</td>
<td><img src="csat/csat1.jpg"/></td>
</tr>
<tr>
<td>3-1. 복사 후 빨간 박스안에 코드를 빈 칸에 알맞게 붙여넣기 !!</td>
<td><img src="csat/csat3.jpg"/></td>
</tr>
                           
</table>                           
</body>
</html>