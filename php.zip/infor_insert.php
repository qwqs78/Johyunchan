<?php
   $title = $_REQUEST["title"];
   $content = $_REQUEST["content"];
   $writer = $_REQUEST["writer"];
    
   if ($title && $content && $writer){
	   $regtime = date("Y-m-d");
	   
	   require("db_connect.php"); //db접속
       $query = $db -> exec("insert into information (title, writer, content, regtime)
	   values('$title', '$writer', '$content','$regtime')"); //insert 할시 exec
   
       header("Location:information.php");
	   exit; //헤더 쓰면 exit 써주면 좋다
   }

 
   
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<script>
   alert('모든 항목이 빈칸 없이 입력되어야 합니다.');
   history.back();
</script>
</body>
</html>
