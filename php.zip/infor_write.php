<?php
   $infor_id = $_REQUEST["infor_id"] ?? 0;
   
    //새글 쓰기 모드
   $content = "";
   $writer = "";
   $title = "";
   $action = "infor_insert.php";
   
   if ($infor_id > 0){ //수정 모드로 셋팅
       require("db_connect.php"); 
       $query = $db -> query("select * from information where infor_id='$infor_id'");
	   
       if ($row = $query->fetch()) {
		 $title = $row["title"];
         $writer = $row["writer"];
         $content = $row["content"];

         $action = "infor_update.php?infor_id=$infor_id";
      }
   }
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        table { width:680px; text-align:center; }
        th    { width:100px; background-color:yellow; }
        input[type=text], textarea { width:100%; }
    </style>
</head>
<body>
<form method="post" action="<?=$action?>">
    <table>
        <tr>
            <th>입시정보</th>
            <td><input type="text" name="title"value="<?=$title?>"></td>
        </tr>
        <tr>
            <th>src</th>
            <td><input type="text" name="content" value="<?=$content?>"></td>
        </tr>
		<tr>
            <th>작성자</th>
            <td><input type="text" name="writer" value="<?=$writer?>"></td>
        </tr>
    </table>
    <br>
    <input type="submit" value="저장">
    <input type="button" value="취소" onclick="history.back()">
</form>
<br>

<h1><a href = "upload_method.php">입시 정보 올리는 방법</a></h1><br>
</body>
</html>