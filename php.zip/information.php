<!doctype html>
<html>
<head>
    <meta charset="utf-8">
	<style>
        table     { width:800px; text-align:center; margin-left:auto; margin-right:auto;font-size: 20px}
		table1    { width:800px; text-align:right; font-size: 20px}
		
        th        { background-color:#86E57F; }
        
        .impor_id      { width: 80px; }
        .title    { width:200px; }
        .writer   { width:200px; }
        .regtime  { width:150px; }

        a         { text-decoration:none; }    
        a:link    { color:blue; }
        a:visited { color:blue; }
        a:hover   { color:red;  }
       
        .center     { text-align:center; }
		
		h1{
		font-size: 50px;
		font-weight:bold;
		color: sandybrown;
	}
    </style>
</head>
<body>
<div style="text-align : center;">
<h1>입시 정보</h1><br>
</div>
<table>

    <tr>
        <th class="impor_id">번호    </th>
        <th class="title"  >제목    </th>
        <th class="writer" >작성자  </th>
        <th class="regtime">작성일시</th>
    </tr>
<?php

   require("db_connect.php");
   $query = $db -> query("select * from information");
   while ($row = $query->fetch()){
?>
    <tr>
        <td><?=$row["infor_id"]?></td>
        <td><a href="iview.php?infor_id=<?=$row["infor_id"]?>"><?=$row["title"]?></a></td>
        <td><?=$row["writer"]?></td>
        <td><?=$row["regtime"]?></td>
    </tr>
<?php
	}
?>
<td><input type="button" value="입시정보 올리기" onclick="location.href='infor_write.php'"></td>
</table><br>

<input type="button" value="메인 이동" onclick="location.href='hcmain.php'"
style="display:block; width:200px; text-align:center;  margin-left:auto; margin-right:auto; font-size:20px; padding:5px;">
</body>
</html> 
