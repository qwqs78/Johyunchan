<?php
   $infor_id = $_REQUEST["infor_id"];

   require("db_connect.php"); //db접속
   
   $query = $db -> query("select * from information where infor_id=$infor_id");
   if ($row = $query->fetch()){
	   $content = $row["content"];
   }
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        table { width:680px; text-align:center; }
        th    { width:100px; background-color:#6BEC62; }
        td    { text-align:center; border:1px solid gray; }
		
		.writer      { width:80px; }
    </style>
</head>
<body>

<input type="button" value="뒤로 이동" onclick="location.href='information.php'"
style="display:block; width:200px; text-align:center; font-size:20px; padding:5px;">
<input type="button" value="삭제" onclick="location.href='infor_delete.php?infor_id=<?=$infor_id?>'"><br>
<input type="button" value="글 수정" onclick="location.href='infor_write.php?infor_id=<?=$infor_id?>'"><br>

<img src = "<?=$content?>" style="display: block; margin: 0 auto;">




<input type="button" value="뒤로 이동" onclick="location.href='information.php'"
style="display:block; width:200px; text-align:center;  margin-left:auto; margin-right:auto; font-size:20px; padding:5px;">
</body>
</html>