<?php
   $test_id = $_REQUEST["test_id"];

   require("db_connect.php"); //db접속
   
   $query = $db -> query("select * from test where test_id=$test_id");
   if ($row = $query->fetch()){
	   $content = $row["content"];
	   $voice = $row["voice"];
   }
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        table { width:680px; text-align:center; }
        th    { width:100px; background-color:#6BEC62; }
        td    { text-align:center; border:1px solid gray; }
		
		.writer      { width:80px; }
		
		audio{
			display:block;
			margin:auto;
			float: right;
		}
    </style>
</head>
<body>
<input type="button" value="뒤로 이동" onclick="location.href='test.php'"
style="display:block; width:200px; text-align:center; font-size:20px; padding:5px;">

<audio src="<?=$voice?>" controls></audio>
<input type="button" value="삭제" onclick="location.href='test_delete.php?test_id=<?=$test_id?>'"><br>
<input type="button" value="글 수정" onclick="location.href='test_write.php?test_id=<?=$test_id?>'"><br>

<img src = "<?=$content?>" style= "display: block; margin: 0 auto;">


</body>
</html>